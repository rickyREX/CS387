import React, { useState } from 'react'
import { useEffect } from 'react'
import { useParams } from 'react-router-dom'
import axios from 'axios'
export default function Instructor() {
    const [instructor_info, setInstructor_info] = useState([]);
    const [instructor_course, setInstructor_course] = useState([]);
    const [course_prev, setCourse_prev] = useState([]);
    const { instructor_id } = useParams()


    useEffect(() => {
        axios.get('http://localhost:5000/instructor/' + instructor_id)
            .then(res => {
                console.log(res.data)
                setInstructor_course(res.data.instructor_course)
                setInstructor_info(res.data.instructor_info)
                setCourse_prev(res.data.course_prev)

            })
            .catch(err => {
                console.log(err)
            })
    }, [])

    return (
        <div className="instructor">
            <h1>Instructor Information</h1>
            <div className="instructor-info">
                {instructor_info.map(info => (
                    <div key={info.instructor_id}>
                        <h2>{info.instructor_id}</h2>
                        <p>{info.name}</p>
                        <p>{info.dept_name}</p>
                
                </div>
                ))}
            </div>
            <div className="instructor-courses">
                <h2>Courses Taught</h2>
                <ul>
                    {instructor_course.map(course => (
                        <li key={course.course_id}>
                            <a href={`/course/${course.course_id}`}>{course.course_id}</a>
                        </li>
                    ))}
                </ul>
            </div>

            <div className="previous-courses">
                <h2>Previous Courses</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Course ID</th>
                            <th>Year</th>
                            <th>Semester</th>
                        </tr>
                    </thead>
                    <tbody>
                        {course_prev.map(course => (
                            <tr key={course.course_id}>
                                <td>
                                    <a href={`/course/${course.course_id}`}>{course.course_id}</a>
                                </td>
                                <td>{course.year}</td>
                                <td>{course.semester}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>

    );
}