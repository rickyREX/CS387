import axios from "axios";
import React, { useState, useEffect } from "react";

export default function Running() {
    const [data, setData] = useState([]);
    useEffect(() => {
        axios.get("http://localhost:5000/course/running")
            .then((res) => {
                console.log(res.data);
                setData(res.data);
            })
            .catch((err) => {
                console.log(err);
            });
    }, []);

    return (
        <div className="running">
            <h1>Running</h1>
            <ul>

                {data.map((item, index) => {
                    return (
                        <ul>
                            <a href={"/course/running/" + item.dept_name}>
                                {item.dept_name}
                            </a>
                        </ul>
                    );
                })}


            </ul>
        </div>
    );
}